from django.shortcuts import render

welcome = ['hi','HI','Hi','hello','HELLO','Hello','hi mrbot','HI MRBOT','Hi Mrbot','hi mr bot','HI MR BOT','Hi Mr Bot','HELLO MR BOT','Hello Mr Bot','hello mr bot','hi bot','HI BOT','Hi bot','hi bot','HI BOT','HELLO BOT','hello bot']
helper=['help','HELP','Help']
veg=['Onion Pizza   >>>   59','Capsicum Pizza   >>>   79','Panner and Onion Pizza   >>>   99','Cheesy Pizza   >>>   99','Veg Loaded   >>>   139','Margherita   >>>   199','Peppy paneer   >>>   309','Cheese N Corn   >>>   309','Moroccan Spice pasta pizza   >>>   309','Cheese N Tomato   >>>   309','Achari Do pyaza   >>>   309','Fresh veggie   >>>   399','Double Cheese Margherita   >>>   399','Farm house   >>>   399','Mexican Green wave   >>>   399','Paneer Makhani   >>>   399','Veggie Paradise   >>>   399','Creamy Tomato Pasta Pizza   >>>   399','Indi Tandoori Paneer   >>>   459','Veg Extravaganza   >>>   459','Deluxe Veggie   >>>   459','Kadhai Paneer   >>>   459']
nonveg=['Chicken sausage   >>>   99','Pepper Barbecue chicken   >>>   109','Non veg loaded   >>>   159','Moroccan Spice pasta pizza   >>>   309','Creamy Tomato Pasta Pizza   >>>   339','Pepper Barbecue and Onion   >>>   339','Chicken Fiesta   >>>   459','Chicken golden delight   >>>    459','Indi chicken Tikka   >>>   579','Chicken Dominator   >>>   579','Non veg supreme   >>>   579','Chicken Pepperoni   >>>   579']
menu=['menu card','MENU CARD','Menu Card']
order=['place order','Place Order','PLACE ORDER']
offer=['offers','offer','Offers','Offer','OFFERS','OFFER']
mydetail=['my details','My Details','MY DETAILS']
track=['track','Track','TRACK']
yes=['YES','Yes','yes']
no=['NO','No','no']
contact=['contact me','contact','Contact Me','Contact','CONTACT ME','CONTACT']
todo=["To view our menu card send >>> 'menu card'",
      "To order a pizza      send >>> 'place order'",
      "To know offer details send >>> 'offer'",
      "To view your details  send >>> 'my details'",
      "To track your order   send >>> 'track'",
      "To contact us         send >>> 'contact me'"]
botdata="hoi"
mydata=[["Welcomes you","Yo Yo pizzas..!"]]

def index(request):
    global botdata
    data=request.POST.get('userval')
    if data==None:
        data="Say Hi"

    if data=="Say Hi":
        botdata=index13(data)
    if data in welcome:
        botdata=index1(data)
    elif data in helper:
        botdata=index2(data)
    elif data in menu:
        botdata=index3(data)
    elif data=='VEG' or data=='veg' or data=='Veg' or data=='vegetarian' or data=='Vegetarian' or data=='VEGETARIAN':
        botdata=index4(data)
    elif data=='NONVEG' or data=='nonveg' or data=='NonVeg' or data=='nonvegetarian' or data=='NonVegetarian' or data=='NONVEGETARIAN' or data=='NON VEG' or data=='non veg' or data=='Non Veg' or data=='non vegetarian' or data=='Non Vegetarian' or data=='NON VEGETARIAN':
        botdata=index5(data)
    elif data in order:
        botdata=index6(data)
    elif data in offer:
        botdata=index7(data)
    elif data in track:
        botdata=index8(data)
    elif data in yes:
        botdata=index9(data)
    elif data in no:
        botdata=index10(data)
    elif data in contact:
        botdata=index11(data)
    else:
        botdata=index12(data)
    mydata.append([botdata,data])
    return render(request, "index.html",{'mydata':mydata})

def index1(data):
    global botdata
    if data in welcome:
        botdata="To know what can i do \n send 'help'"
    return botdata

def index2(data):
    global botdata
    if data in helper:
        botdata="i can do list of things as follows:\nTo view our menu card send-'MENU CARD'\nTo order a pizza send --------'PLACE ORDER'\nTo know offer details send --'OFFER'\nTo track your order send-----'TRACK'\nTo contact us send -----------'CONTACT ME'"
    return botdata

def index3(data):
    global botdata
    if data in menu:
        botdata="Do you want Veg or Non-Veg"
    return botdata

def index4(data):
    global botdata
    if data == 'VEG' or data == 'veg' or data == 'Veg' or data == 'vegetarian' or data == 'Vegetarian' or data == 'VEGETARIAN':
        botdata="Onion Pizza---------------------Rs 59\nCapsicum Pizza-----------------Rs 79\nPanner and Onion Pizza------Rs 99\nCheesy Pizza---------------------Rs 99\nVeg Loaded----------------------Rs 139\nMargherita-----------------------Rs 199\nPeppy paneer---------------------Rs 309\nCheese N Corn--------------------Rs 309\nMoroccan Spice pasta pizza---Rs 309\nCheese N Tomato-----------------Rs 309\nAchari Do pyaza-----------------Rs 309\nFresh veggie-----------------------Rs 399\nDouble Cheese Margherita------Rs 399\nFarm house------------------------Rs 399\nMexican Green wave-------------Rs 399\nPaneer Makhani------------------Rs 399\nVeggie Paradise-------------------Rs 399\nCreamy Tomato Pasta Pizza---Rs 399\nIndi Tandoori Paneer------------Rs 459\nVeg Extravaganza---------------Rs 459\nDeluxe Veggie---------------------Rs 459\nKadhai Paneer--------------------Rs 459\nTo place a new order send me ' PLACE ORDER '\nTo know what can i do send me ' HELP '"
    return botdata

def index5(data):
    global botdata
    if data=='NONVEG' or data=='nonveg' or data=='NonVeg' or data=='nonvegetarian' or data=='NonVegetarian' or data=='NONVEGETARIAN' or data=='NON VEG' or data=='non veg' or data=='Non Veg' or data=='non vegetarian' or data=='Non Vegetarian' or data=='NON VEGETARIAN':
        botdata="Chicken sausage------------------Rs 99\nPepper Barbecue chicken-------Rs 109\nNon veg loaded-------------------Rs 159\nMoroccan Spice pasta pizza---Rs 309\nCreamy Tomato Pasta Pizza---Rs 339\nPepper Barbecue and Onion----Rs 339\nChicken Fiesta--------------------Rs 459\nChicken golden delight----------Rs  459\nIndi chicken Tikka---------------Rs 579\nChicken Dominator--------------Rs 579\nNon veg supreme-----------------Rs 579\nChicken Pepperoni---------------Rs 579\nTo place a new order send me ' PLACE ORDER '\nTo know what can i do send me ' HELP '"
    return botdata

def index6(data):
    global botdata
    if data in order:
        botdata="To Place a new order please click on 'PLACE ORDER' button at the right-top corner of this page\nThen use USERNAME as ' mrbot ' and PASSWORD as ' mrbot '\nNow choose ' Place order '\nThen click ' Add Place Order '\nTo know what can i do send me ' HELP '"
    return botdata

def index7(data):
    global botdata
    if data in offer:
        botdata="There are 2 offers available for you corrently:\n1. Buy 2 in NonVeg Pizza get 1 in Veg Pizza free\n2. Buy 3 Pizza get any Dessert free\nTo place a new order send me ' PLACE ORDER '\nTo know what can i do send me ' HELP '"
    return botdata

def index8(data):
    global botdata
    if data in track:
        botdata="Have you placed your order? send ' YES ' or ' NO '"
    return botdata

def index9(data):
    global botdata
    if data in yes:
        botdata="Your order is placed successfully\n if you not recieved your order details message to your mobile then you may be entered your details incorrectly\nTo order again send me ' PLACE ORDER '\nTo know what can i do send me ' HELP '"
    return botdata

def index10(data):
    global botdata
    if data in no:
        botdata="You can order your pizzas first then you can track your order status\nTo order your pizzas send me ' PLACE ORDER '\nTo track your order ststus send me ' TRACK '\nTo know what can i do send me ' HELP '"
    return botdata

def index11(data):
    global botdata
    if data in contact:
        botdata="Im Mr BOT \nYO YO PIZZA..!,\nyoyopizza@gmail.com \n9876543210 \n6th main road, shanthi colony,\nAnnanagar chennai.\nTo know what can i do send me ' HELP '"
    return botdata

def index12(data):
    global botdata
    if data=="Say Hi":
        botdata="Hi, Im Mr bot"
    else:
        botdata="Sorry, Come again..!"
    return botdata
def index13(data):
    global botdata
    botdata="Hi, Im Mr bot"
    return botdata