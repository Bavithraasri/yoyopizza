from django.apps import AppConfig


class ChatbotConfig(AppConfig):
    name = 'chatbot'
