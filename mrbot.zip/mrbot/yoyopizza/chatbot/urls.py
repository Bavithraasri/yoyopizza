from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('', views.index1, name='index1'),
    path('', views.index2, name='index2'),
    path('', views.index3, name='index3'),
    path('', views.index4, name='index4'),
    path('', views.index5, name='index5'),
    path('', views.index1, name='index6'),
    path('', views.index2, name='index7'),
    path('', views.index3, name='index8'),
    path('', views.index4, name='index9'),
    path('', views.index5, name='index10'),
    path('', views.index1, name='index11'),
    path('', views.index1, name='index12'),
    path('', views.index1, name='index13'),
]
