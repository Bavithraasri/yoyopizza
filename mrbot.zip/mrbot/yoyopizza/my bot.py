print("Hi")

items={"onion pizza":59,"capsicum pizza":79,"panner and onion pizza":99,"cheesy pizza":99,"veg loaded":139,"margherita":199,"peppy paneer":309,"cheese n corn":309,"moroccan spice pasta pizza":309,"cheese n tomato":309,"achari do pyaza":309,"fresh veggie":399,"double cheese margherita":399,"farm house":399,"mexican green wave":399,"paneer makhani":399,"veggie paradise":399,"creamy tomato pasta pizza":399,"indi tandoori paneer":459,"veg extravaganza":459,"deluxe veggie":459,"kadhai paneer":459,"chicken sausage":99,"pepper barbecue chicken":109,"non veg loaded":159,"moroccan spice pasta pizza":309,"creamy tomato pasta pizza":339,"pepper barbecue and onion":339,"chicken fiesta":459,"chicken golden delight": 459,"indi chicken tikka":579,"chicken dominator":579,"non veg supreme":579,"chicken pepperoni":579,"tomato ketchup":1,"cheesy jalapeno dip":25,"cheesy dip":25,"veg parcel":39,"crunchy strips":59,"crinkle fries":59,"potato cheese shots":59,"garlic breadsticks":99,"taco mexicana veg":118,"moroccan spice pasta veg":129,"tikka masala pasta veg":129,"cheesy jalapeno pasta veg":129,"creamy tomato pasta veg":129,"white pasta italiano veg":129,"stuffed garlic breadsticks":145,"brownie fantasy":59,"choco lava cake":99,"butterscotch mousse cake":99,"red velvet lava cake":129,"blueberry cheese lava cake":129,"bailley premium water":20,"slice(350ml)":50,"pepsi(500ml)":60,"7up(500ml)":60,"miranda(500ml)":60,"alphonsos from ratnagiri":70,"pink guavas from dakshin india":70,"mixed fruit from himalayas":70,}

welcome=['hi','HI','Hi','hello','HELLO','Hello',]
helper=['help','HELP','Help']
menu=['menu card','MENU CARD','Menu Card']
order=['place order','Place Order','PLACE ORDER']
offer=['offers','offer','Offers','Offer','OFFERS','OFFER']
mydetail=['my details','My Details','MY DETAILS']
track=['track','Track','TRACK']
contact=['contact me','contact','Contact Me','Contact','CONTACT ME','CONTACT']
todo=["To view our menu card send >>> 'menu card'",
      "To order a pizza      send >>> 'place order'",
      "To know offer details send >>> 'offer'",
      "To view your details  send >>> 'my details'",
      "To track your order   send >>> 'track'",
      "To contact us         send >>> 'contact me'"]
if input() in welcome:
    print("Im Mr bot,\nyour good name please:")
    name=input()
    print("your mobile number please:")
    mobile=input()
    print("To know what can i do \n send 'help'")
while(1):
    usrval=input()
    if usrval in helper:
        print(name+" i can do list of things as follows:",*todo,sep='\n')
    elif usrval in menu:
        print(*items,sep="\n")
        print("To place order please click on the order button on the top right cornerof this page")
    elif usrval in order:
        print("To place order please click on the order button on the top right cornerof this page")
    elif usrval in offer:
        print("Sorry "+name+" there are no offers currently..!")
    elif usrval in mydetail:
        print("Name       :"+name)
        print("Mobile no  :"+mobile)
    elif usrval in track:
        print("your order is on processing")
    elif usrval in contact:
        print("YO YO PIZZA,\nyoyopizza@gmail.com \n9876543210 \n6th main road, shanthi colony,\nAnnanagar chennai.")
    else:
        print("Sorry,"+name+" I can't get you")
